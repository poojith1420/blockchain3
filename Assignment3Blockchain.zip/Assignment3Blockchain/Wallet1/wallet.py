import datetime
import os
import json
import hashlib
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
import base64
import socket
import struct
import threading 
import time


server_host = '127.0.0.1'
server_port = 5000

class SocketHandler:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect()

    def connect(self):
        self.socket.connect((self.host, self.port))
    
    def send(self,data):
        data_str = json.dumps(data)
        data_length = len(data_str)
        self.socket.send(struct.pack('!I', data_length))
        print("Sending :",json.dumps(data,indent=4))
        self.socket.send(data_str.encode())
        return True

    def receive(self):
        while True:
            data_length_bytes = self.socket.recv(4)
            if len(data_length_bytes) < 4:
                continue
            data_length = struct.unpack('!I', data_length_bytes)[0]
            # Receive and reconstruct the data from the server
            received_data = b""
            remaining_bytes = data_length
            while remaining_bytes > 0:
                chunk = self.socket.recv(1024)
                if not chunk:
                    break
                received_data += chunk
                remaining_bytes -= len(chunk)
            # Deserialize the JSON data
            if remaining_bytes == 0:
                large_data = json.loads(received_data.decode())
                return large_data
                

    def close(self):
        self.socket.close()

def request_blockchain(socket_handler):
    blockchain_request_payload = {"action":"block_chain_request"}
    socket_handler.send(blockchain_request_payload)
    blockchain = socket_handler.receive()
    return blockchain

def check_balance(blockchain,wallet_address):
    balance = 0.0  
    print(f"Checking balance of wallet: {wallet_address}")
    for block in blockchain["blockchain"]:
        if "body" in block:
            if "coinbase_transaction" in block["body"][0]["content"]:
                if block["body"][0]["content"]["coinbase_transaction"]["to"] == wallet_address:
                        balance +=  block["body"][0]["content"]["coinbase_transaction"]["amount"]
            
            if "transaction" in block["body"][0]["content"]:
                for transaction in block["body"][0]["content"]["transaction"]["transactions_data"]:
                    if transaction["from"] == wallet_address:
                        balance -= transaction["amount"]
                    if transaction["to"] == wallet_address:
                        balance += transaction["amount"] 
            
            if "data" in block["body"][0]["content"]:  
                transactions = block["body"][0]["content"]["data"]["transaction"]["transaction_data"]
                if isinstance(transactions, dict):
                        if transactions["from"] == wallet_address:
                            balance -= transactions["amount"]  
                        if transactions["to"] == wallet_address:
                            balance += transactions["amount"]  
                
    return balance

def load_or_generate_wallet():
    pem_file_path = 'wallet.pem'
    if os.path.exists(pem_file_path):
        print("Wallet already exists, loading Wallet...")
        with open(pem_file_path, 'rb') as pem_file:
            private_key = RSA.import_key(pem_file.read())
            wallet_address = hashlib.sha256(private_key.publickey().export_key()).hexdigest()
            print("Wallet Address:",wallet_address)
        wallet_mode(wallet_address,private_key)
    else:
        generate_wallet()
    
            
def generate_wallet():
    key = RSA.generate(2048)
    private_key = key.export_key()
    wallet_address = hashlib.sha256(key.publickey().export_key()).hexdigest()
    with open('wallet.pem', 'wb') as pem_file:
        pem_file.write(private_key)
    print("Wallet created successfully.")
    print("Wallet Address:", wallet_address)
    wallet_mode(wallet_address,private_key)

def get_public_key(private_key):
    return base64.b64encode(private_key.publickey().export_key()).decode()

def sign_transaction(transaction_data,private_key):
    if not private_key:
        raise ValueError("Private key not available for signing.")

    h = SHA256.new(json.dumps(transaction_data).encode())
    signature = pkcs1_15.new(private_key).sign(h)
    return signature

def create_transaction(from_address, to_address, amount, private_key,socket_handler):
    ct = datetime.datetime.now()
    timestamp = ct.timestamp()
    
    # Check If The Wallet Exists
    if private_key is None or not isinstance(private_key, RSA.RsaKey):
        print("Wallet does not exist. Please create a wallet first.")
        return

    transaction_validator = {}
    # Create A Transaction
    transaction_data = {
        "to": to_address,
        "from": from_address,
        "amount": amount,
        "timestamp": timestamp
    }

    ### Sign The Transaction
    signature = sign_transaction(transaction_data,private_key)    
    
    # Include the Transaction Signature and Public Key in the transaction as transaction_validator
    transaction_validator["signature"] = signature.hex()
    transaction_validator["public_key"] = get_public_key(private_key)
    transaction = {"transaction":{"transaction_data":transaction_data,"transaction_validator":transaction_validator}}
    json_data = json.dumps(transaction)
    hash_value = hashlib.sha256(json_data.encode()).hexdigest()
    json_filename = f"{hash_value}.json"
    json_str = {"action":"new_transaction_from_wallet","data":transaction,"filename":json_filename}
    
    if socket_handler.send(json_str) :
        ack = socket_handler.receive()
        print("Acknowldegment Recieved : ",json.dumps(ack,indent=4))
    else:
        print("Failed To Send The Transcation To Node")
        
def wallet_mode(wallet_address,private_key):
    discovery_payload = {"discovery":"wallet","name": f"{wallet_address}"}
    socket_handler = SocketHandler(server_host, server_port)
    socket_handler.send(discovery_payload)
    #response = socket_handler.()
    #print("Response from server:", response)
    print("\nWallet Menu:")
    print("1. Create Transaction")
    print("2. Check Current Wallet Balance")
    print("3. Check Balance Of Other Wallets")
    choice = input("Select an option (1/2/3): ")
    if choice == '1':
        from_address = wallet_address
        to_address = input("Enter Recipient's Wallet Address: ")
        amount = float(input("Enter amount to send: "))
        create_transaction(from_address, to_address, amount,private_key,socket_handler)
    elif choice == '2':
        node_blockchain = request_blockchain(socket_handler)
        sender_current_balance = check_balance(node_blockchain,wallet_address)
        print(f"Current Wallet - {wallet_address} , Balance : {sender_current_balance} ")
    elif choice == '3':
        print("Enter The Wallet Address To Check :")
        entered_wallet_address = input()
        node_blockchain = request_blockchain(socket_handler)
        sender_current_balance = check_balance(node_blockchain,entered_wallet_address)
        print(f"Wallet - {wallet_address} , Balance : {sender_current_balance} ")
    
 
load_or_generate_wallet()