import socket
import json
import struct
import threading
import os
import hashlib
import sys
import datetime

server_host = '127.0.0.1'
server_port = 5000

class SocketHandler:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect()

    def connect(self):
        self.socket.connect((self.host, self.port))
    
    def send(self,data):
        data_str = json.dumps(data)
        data_length = len(data_str)
        # Send the data length as a 4-byte prefix
        self.socket.send(struct.pack('!I', data_length))
        # Send the data to the client
        print("Sending :",json.dumps(data,indent=4))
        self.socket.send(data_str.encode())
        
        return True

    def receive(self):
        while True:
            data_length_bytes = self.socket.recv(4)
            if len(data_length_bytes) < 4:
                continue
            data_length = struct.unpack('!I', data_length_bytes)[0]
            # Receive and reconstruct the data from the server
            received_data = b""
            remaining_bytes = data_length
            while remaining_bytes > 0:
                chunk = self.socket.recv(1024)
                if not chunk:
                    break
                received_data += chunk
                remaining_bytes -= len(chunk)
            # Deserialize the JSON data
            if remaining_bytes == 0:
                large_data = json.loads(received_data.decode())
                return large_data

    def close(self):
        self.socket.close()

def request_blockchain(socket_handler):
    blockchain_request_payload = {"action":"block_chain_request"}
    socket_handler.send(blockchain_request_payload)
    blockchain = socket_handler.receive()
    return blockchain
                         
def start_node():
    print("Node3 Running...")

    if not os.path.exists("pending_transactions"):
        os.makedirs("pending_transactions")

    if not os.path.exists("processed_transactions"):
        os.makedirs("processed_transactions")
    
    if not os.path.exists("discarded_transactions"):
        os.makedirs("discarded_transactions")

    if not os.path.exists("blocks"):
        os.makedirs("blocks")
    
    discovery_payload = {"discovery":"nodes","name": "Node-3"}
    socket_handler = SocketHandler(server_host, server_port)
    socket_handler.send(discovery_payload)
    
    while True:
        data = socket_handler.receive()
        if isinstance(data, dict) and "action" in data:
            if data["action"] == "new_transaction_from_wallet":
                print("\n New Transaction From Wallet : ", json.dumps(data, indent=4)+"\n" )
            ### Create Local Copy Of That Transcation in pending transcations
                node_blockchain = request_blockchain(socket_handler)
                for block in node_blockchain["blockchain"]:
                    block_name = block["transaction_hash"]
                    block_filename = os.path.join("blocks", f"{block_name}.json")
                    with open(block_filename, "w") as file:
                        file.write(json.dumps(block))
                    file.close()
                    
                transaction_filename = os.path.join("pending_transactions", data["filename"])              
                with open(transaction_filename, "w") as json_file:
                    json_file.write(json.dumps(data["data"]))

                
            if data["action"] == "block_reject":
                os.rename(
                    os.path.join("pending_transactions", data["filename"]),
                    os.path.join("discarded_transactions", data["filename"])
                )
            
            if data["action"] == "block_created":
                print("Block Created : ",json.dumps(data, indent= 4))
                file_name = data["transaction_hash"]
                block_filename = os.path.join("blocks",f"{file_name}.json")
                with open(block_filename, "w") as file:
                    file.write(data["transaction"])
                file.close()
                os.rename(
                    os.path.join("pending_transactions", data["filename"]),
                    os.path.join("processed_transactions", data["filename"])
                )

        else:
            print("Log Data: ", json.dumps(data, indent=4))

start_node()