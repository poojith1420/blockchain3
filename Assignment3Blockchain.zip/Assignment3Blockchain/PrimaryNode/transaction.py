import socket
import json
import struct
import threading
import os
import hashlib
import sys
import datetime

ifo_wallets = [
    "f07927e45d19e31de1d906b764c0c38dc8d96bd3398bbe6663d6602bc38645c3",
    "e3b132260d7e4a78755f843fe0bf9984764b283607cebff68a3293a485807018",
    "1e6eb9a353d8c3ab005de87ffc6d50a159b732c94efb3f30678fd28a54398c9b",
    ]
ifo_offering_ammount = 100 ## Intial Coins To Account

wallet_clients = []
nodes_clients = []
miners_clients = []
thread_exit_flags = {}  


def handle_client(client_socket):
    try:
        thread_exit_flags[client_socket] = False
        while not thread_exit_flags[client_socket]:
            data_length_bytes = client_socket.recv(4)
            if len(data_length_bytes) < 4:
                continue
            data_length = struct.unpack('!I', data_length_bytes)[0]
            received_data = b""
            remaining_bytes = data_length
            while remaining_bytes > 0:
                chunk = client_socket.recv(1024)
                if not chunk:
                    break
                received_data += chunk
                remaining_bytes -= len(chunk)

            if remaining_bytes == 0:
                data = json.loads(received_data.decode())
                if "discovery" in data:
                    if data["discovery"] == "wallet":
                        wallet_clients.append(client_socket)
                    elif data["discovery"] == "miner":
                        miners_clients.append(client_socket)
                    elif data["discovery"] == "nodes":
                        nodes_clients.append(client_socket) 
                    process_data(data,client_socket) 
                elif "action" in data:
                    process_data(data,client_socket)
 
                    
    except Exception as e:
        print(f"Client disconnected: {e}")
        thread_exit_flags[client_socket] = True
        if client_socket in wallet_clients:
            wallet_clients.remove(client_socket)
        elif client_socket in nodes_clients:
            nodes_clients.remove(client_socket)
        elif client_socket in miners_clients:
            miners_clients.remove(client_socket)
        client_socket.close()
    finally:
        client_socket.close()
        thread_exit_flags[client_socket] = True
        if client_socket in wallet_clients:
            wallet_clients.remove(client_socket)
        elif client_socket in nodes_clients:
            nodes_clients.remove(client_socket)
        elif client_socket in miners_clients:
            miners_clients.remove(client_socket)
        print("Client connection closed")
        
def send_message(data,client_socket):
    json_data = json.dumps(data)
    data_length = len(json_data)
    length_bytes = struct.pack('!I', data_length)
    client_socket.send(length_bytes)
    client_socket.send(json_data.encode()) 
    return True
        
def close_client(client_socket):
    client_socket.close()    
    
def process_data(data,client_socket):
    if isinstance(data, dict) and "action" in data:
        if data["action"] == "new_transaction_from_wallet":
            print("\n New Transaction From Wallet : ", json.dumps(data, indent=4)+"\n" )
            ### Create Local Copy Of That Transcation in pending transcations
            transaction_filename = os.path.join("pending_transactions", data["filename"])
            with open(transaction_filename, "w") as json_file:
                json_file.write(json.dumps(data["data"]))
            
            ### Broadcast To Miner And Miner And Acknowledge Wallet
            if broadcast_data(data,nodes_clients,"nodes"):
                print("Transaction Shared With Other Nodes")
                if broadcast_data(data,miners_clients,"miner"):
                    print("Sent Transaction To Miner To Verify")
                    if broadcast_data(data,wallet_clients,"wallet"):
                        print("Sent Acknowledgment To Wallet ")
        
        if data["action"] == "block_chain_request":
            local_blockchain = send_local_blockchain()
            if client_socket in wallet_clients:
                print("Wallet Requested for Blockchain From Primary Node")
                broadcast_data(local_blockchain,wallet_clients,"wallet")
            elif client_socket in nodes_clients:
                print("Nodes Requested for Blockchain From Primary Node ")
                broadcast_data(local_blockchain,nodes_clients,"nodes")
            elif client_socket in miners_clients:
                print("Miner Requested for Blockchain From Primary Node")
                broadcast_data(local_blockchain,miners_clients,"miner")
        
        if data["action"] == "block_reject":
            os.rename(
                os.path.join("pending_transactions", data["filename"]),
                os.path.join("discarded_transactions", data["filename"])
            )
            if broadcast_data(data,nodes_clients,"nodes"):
                print("Block Reject Broadcasted With Other Nodes")
            
        if data["action"] == "block_created":
             # TODO Broadcast To Other Nodes
            print("Block Created : ",json.dumps(data, indent= 4))
            file_name = data["transaction_hash"]
            block_filename = os.path.join("blocks",f"{file_name}.json")
            with open(block_filename, "w") as file:
                file.write(data["transaction"])
            file.close()
            os.rename(
                os.path.join("pending_transactions", data["filename"]),
                os.path.join("processed_transactions", data["filename"])
            )
            if broadcast_data(data,nodes_clients,"nodes"):
                print("Block Created Broadcasted With Other Nodes")

            
    else:
        print("Log Data: ", json.dumps(data, indent=4))
        
def is_socket_active(client_socket):
    try:
        error_code = client_socket.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
        if error_code == 0:
            return True 
    except Exception as e:
        return False
    return False  
            
def broadcast_data(data,clients_list,type_var):
    for client_socket in clients_list:
        if is_socket_active(client_socket):
            try:
                if send_message(data,client_socket):
                    print(f"\n Sent To {type_var} : {json.dumps(data, indent=4)} \n")   
                    if type_var == "wallet":  
                        clients_list.remove(client_socket) #Remove Wallet Because It Connecting And Disconecting 
                    return True
            except Exception as e:
                print(f"Error broadcasting data to a client: {e}")
        else:
            if client_socket in clients_list:
                clients_list.remove(client_socket)
                   
                   
def create_genesis_block():
    ct = datetime.datetime.now()
    timestamp = ct.timestamp()
    previous_block_hash = "0" * 64
    block_body = []
    transactions_data = []
    for wallet in ifo_wallets:
        transactions_data.append({
                 "to": wallet, 
                 "from": "IFO-BASE", 
                 "amount": ifo_offering_ammount, 
                 "timestamp":timestamp
        })
    transactions = {"transaction": {"transactions_data": transactions_data}}
    block_body.append({
        "hash": "0" * 64 ,
        "content": transactions
    })   
    blockbody_data = block_body
    blockbody_json = json.dumps(blockbody_data)
    blockbody_hash = hashlib.sha256(blockbody_json.encode()).hexdigest()

    block_header = {
        "height": 1,
        "timestamp": timestamp,
        "previousblock": previous_block_hash,
        "hash": blockbody_hash
    }
    
    block_data = {
        "header": block_header,
        "body": block_body
    }
    
    block_json = json.dumps(block_data)

    block_hash = hashlib.sha256(block_json.encode()).hexdigest()
    block_header["hash"] = block_hash
    
    block_filename = os.path.join("blocks",f"{previous_block_hash}.json")
    if not os.path.exists(block_filename):
        with open(block_filename, "w") as file:
            file.write(block_json)
        file.close()
        print("Genesis Block Created In Blockchain")
    else:
        print("Genesis Block Already Found In The Blockchain, Thus Continuing Blockchain")
    return True
                   
                   
def send_local_blockchain():
    blockchain = []
    if os.path.exists("blocks"):
        block_files = [filename for filename in os.listdir("blocks") if filename.endswith(".json")]
        for filename in block_files:
            with open(os.path.join("blocks"+"\\"+filename), "r") as file:
                block_data = json.load(file)
                block_data["transaction_hash"]=filename[:-5]
                blockchain.append(block_data)
    return {
            "action":"primary_blockchain",
            "blockchain":blockchain
    }
                   
def start_server(host, port):
    # Create a socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))  
    server_socket.listen() 

    print("Primay Node Running...")

    if not os.path.exists("pending_transactions"):
        os.makedirs("pending_transactions")

    if not os.path.exists("processed_transactions"):
        os.makedirs("processed_transactions")
    
    if not os.path.exists("discarded_transactions"):
        os.makedirs("discarded_transactions")

    if not os.path.exists("blocks"):
        os.makedirs("blocks")
    
    if create_genesis_block():
        while True:
            client_socket, client_address = server_socket.accept()
            print(f"Connection from {client_address}")
            client_thread = threading.Thread(target=handle_client, args=(client_socket,))
            client_thread.start()

if __name__ == "__main__":
    server_host = '127.0.0.1'
    server_port = 5000
    start_server(server_host, server_port)
