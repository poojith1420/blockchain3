import datetime
import os
import json
import hashlib
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
import base64
import socket
import struct
import threading 
import time

server_host = '127.0.0.1'
server_port = 5000

class SocketHandler:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect()

    def connect(self):
        self.socket.connect((self.host, self.port))
    
    def send(self,data):
        data_str = json.dumps(data)
        data_length = len(data_str)
        # Send the data length as a 4-byte prefix
        self.socket.send(struct.pack('!I', data_length))
        # Send the data to the client
        print("Sending :",json.dumps(data,indent=4))
        self.socket.send(data_str.encode())
        
        return True

    def receive(self):
        while True:
            data_length_bytes = self.socket.recv(4)
            if len(data_length_bytes) < 4:
                continue
            data_length = struct.unpack('!I', data_length_bytes)[0]
            # Receive and reconstruct the data from the server
            received_data = b""
            remaining_bytes = data_length
            while remaining_bytes > 0:
                chunk = self.socket.recv(1024)
                if not chunk:
                    break
                received_data += chunk
                remaining_bytes -= len(chunk)
            # Deserialize the JSON data
            if remaining_bytes == 0:
                large_data = json.loads(received_data.decode())
                return large_data

    def close(self):
        self.socket.close()

def load_or_generate_wallet():
    pem_file_path = 'wallet.pem'
    if os.path.exists(pem_file_path):
        print("Miner Wallet already exists, loading Miner Wallet...")
        with open(pem_file_path, 'rb') as pem_file:
            private_key = RSA.import_key(pem_file.read())
            wallet_address = hashlib.sha256(private_key.publickey().export_key()).hexdigest()
            print("Miner Wallet Address:",wallet_address)
        miner(wallet_address,private_key)
    else:
        generate_wallet()
    
            
def generate_wallet():
    key = RSA.generate(2048)
    private_key = key.export_key()
    wallet_address = hashlib.sha256(key.publickey().export_key()).hexdigest()
    with open('wallet.pem', 'wb') as pem_file:
        pem_file.write(private_key)
    print("Wallet created successfully.")
    print("Wallet Address:", wallet_address)
    miner(wallet_address,private_key)

def check_balance(blockchain,wallet_address):
    balance = 0.0  
    print(f"Checking balance of wallet: {wallet_address}")
    for block in blockchain["blockchain"]:
        if "body" in block:
            if "coinbase_transaction" in block["body"][0]["content"]:
                if block["body"][0]["content"]["coinbase_transaction"]["to"] == wallet_address:
                        balance +=  block["body"][0]["content"]["coinbase_transaction"]["amount"]
            
            if "transaction" in block["body"][0]["content"]:
                for transaction in block["body"][0]["content"]["transaction"]["transactions_data"]:
                    if transaction["from"] == wallet_address:
                        balance -= transaction["amount"]
                    if transaction["to"] == wallet_address:
                        balance += transaction["amount"] 
            
            if "data" in block["body"][0]["content"]:  
                transactions = block["body"][0]["content"]["data"]["transaction"]["transaction_data"]
                if isinstance(transactions, dict):
                        if transactions["from"] == wallet_address:
                            balance -= transactions["amount"]  
                        if transactions["to"] == wallet_address:
                            balance += transactions["amount"]  
                
    return balance

def request_blockchain(socket_handler):
    blockchain_request_payload = {"action":"block_chain_request"}
    socket_handler.send(blockchain_request_payload)
    blockchain = socket_handler.receive()
    return blockchain

def verify_walletaddress(public_key):
    public_key_bytes = base64.b64decode(public_key)
    return hashlib.sha256(public_key_bytes).hexdigest()

def verify_transaction(transaction_data, signature, sender_public_key):
    public_key_bytes = base64.b64decode(sender_public_key)
    sender_public_key = RSA.import_key(public_key_bytes)
    signature = bytes.fromhex(signature)
    h = SHA256.new(json.dumps(transaction_data).encode())
    try:
        pkcs1_15.new(sender_public_key).verify(h, signature)
        return True  # Signature is valid
    except (ValueError, TypeError):
        return False  # Signature is not valid
    
def get_previous_block_hash():
    block_files = [filename for filename in os.listdir("blocks") if filename.endswith(".json")]
    if block_files:
        block_files.sort(key=lambda x: int(x.split('.')[0], 16))
        latest_block = block_files[-1]
        if latest_block == "genesis.json":
            # Special case for the genesis block
            previous_block_hash = "0" * 64  # All zeros for the first block
        else:
            with open(os.path.join("blocks", latest_block), "r") as file:
                block_data = json.load(file)
                previous_block_hash = block_data["header"]["hash"]
    else:
        previous_block_hash = "0" * 64  # All zeros for the first block
    return previous_block_hash
    
def get_next_block_height():
    block_files = [filename for filename in os.listdir("blocks") if filename.endswith(".json")]
    max_height = -1
    for filename in block_files:
        with open(os.path.join("blocks", filename), "r") as file:
            block_data = json.load(file)
            height = block_data["header"]["height"]
            if height > max_height:
                max_height = height
    return max_height + 1

def miner(wallet_address,private_key):
    if not os.path.exists("blocks"):
        os.makedirs("blocks")
    discovery_payload = {"discovery":"miner","name": f"Miner - {wallet_address}"}
    print("Miner Started")
    socket_handler = SocketHandler(server_host, server_port)
    socket_handler.send(discovery_payload)
    while True:
        data = socket_handler.receive()
        if "action" in data:
            if data["action"] == "new_transaction_from_wallet":
                print("New Transaction Recieved : ",json.dumps(data,indent=4))
                ## Request For Blockchain 
                node_blockchain = request_blockchain(socket_handler)
                
                ## Create A Local Copy Of BlockChain
                for block in node_blockchain["blockchain"]:
                    block_name = block["transaction_hash"]
                    block_filename = os.path.join("blocks", f"{block_name}.json")
                    with open(block_filename, "w") as file:
                        file.write(json.dumps(block))
                    file.close()
                
                ## Check Blance From The BlockChain Recieved 
                sender_wallet = data["data"]["transaction"]["transaction_data"]["from"]
                amount =  data["data"]["transaction"]["transaction_data"]["amount"]
                receiver_wallet = data["data"]["transaction"]["transaction_data"]["to"]
                
                ### Get Current Balance From Blockchain
                sender_current_balance = check_balance(node_blockchain,sender_wallet)
                
                print("Sender Balance :",sender_current_balance)
                if float(sender_current_balance) < float(amount):
                    print(f"The Sender : {sender_wallet} is having low blance, henece discarding the transaction")
                    block_reject_payload = {"action":"block_reject","filename":data["filename"],"message":"No Succiffent Balance From Sender Waller "}
                    socket_handler.send(block_reject_payload)
                    
                else:
                    ### Processing Transaction 
                    ct = datetime.datetime.now()
                    timestamp = ct.timestamp()
                    previous_block_hash = get_previous_block_hash()

                    block_body = []
                    if 'transaction' in data["data"] and 'transaction_validator' in data["data"]['transaction']:
                        ### Check For Transaction Signature And Public Key of The Sender [From_Address]
                        if 'signature' in data["data"]['transaction']['transaction_validator'] and 'public_key' in data["data"]['transaction']['transaction_validator']:
                            ## Generating Wallet Address From The Public Key Provided By Transaction and Matching it With From address
                            if data["data"]['transaction']['transaction_data']['from'] == verify_walletaddress(data["data"]['transaction']['transaction_validator']['public_key']) :
                                print("Validated Wallet Address Successfully")
                                ##### Checking The Transaction Data, With Signature And With The PublicKey Befor Putting Inside Block
                                if(verify_transaction(data["data"]['transaction']['transaction_data'],data["data"]['transaction']['transaction_validator']['signature'],data["data"]['transaction']['transaction_validator']['public_key'])):
                                    print("Transaction Validated Sucessfully")
                                    ### Appending Valid Transaction To The Block Body
                                    block_body.append({
                                            "hash": data["filename"][:-5],
                                            "content": {
                                                "coinbase_transaction":{
                                                "from":"COIN-BASE",
                                                "to":wallet_address,
                                                "amount":10
                                                },
                                                "data":data["data"]
                                                }
                                            })
                                    blockbody_data = block_body
                                    blockbody_json = json.dumps(blockbody_data)
                                    blockbody_hash = hashlib.sha256(blockbody_json.encode()).hexdigest()
                                
                                    block_header = {
                                        "height": get_next_block_height(),
                                        "timestamp": timestamp,
                                        "previousblock": previous_block_hash,
                                        "hash": blockbody_hash
                                    }

                                    block_data = {
                                        "header": block_header,
                                        "body": block_body
                                    }
                                    
                                
                                    block_json = json.dumps(block_data)
                                    block_hash = hashlib.sha256(block_json.encode()).hexdigest()
                                    block_header["hash"] = block_hash

                                    block_filename = os.path.join("blocks", f"{block_hash}.json")
                                    with open(block_filename, "w") as file:
                                        file.write(block_json)
                                    
                                    block_payload = {"action":"block_created","transaction":block_json,"transaction_hash":block_hash,"filename":data["filename"]}
                                    socket_handler.send(block_payload)
                                else:
                                    block_reject_payload = {"action":"block_reject","filename":data["filename"],"message":"Signature Is Tamppered/In Valid, Hence Discarding The Transaction"}
                                    socket_handler.send(block_reject_payload)
                            else:
                                print("Failed To Verify Wallet Address Form Private Key")
                                block_reject_payload = {"action":"block_reject","filename":data["filename"],"message":"Failed To Verify Wallet Address Form Private Key,Hence Discarding The Transcation"}
                                socket_handler.send(block_reject_payload)
                        else:
                            print("Transaction Is Not In Valid Fomart, Hemere Dicarding Transaction")
                            block_reject_payload = {"action":"block_reject","filename":data["filename"],"message":"Transaction Is Not In Valid Fomart, Hence Dicarding Transaction"}
                            socket_handler.send(block_reject_payload)
                    else:
                        print("Transaction Is Not In Valid Fomart, Hemere Dicarding Transaction")
                        block_reject_payload = {"action":"block_reject","filename":data["filename"],"message":"Transaction Is Not In Valid Fomart, Hence Dicarding Transaction"}
                        socket_handler.send(block_reject_payload)
                                                 
                        
load_or_generate_wallet()